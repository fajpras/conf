
create database Sosmed;
use Sosmed;

create table user( 
userId int not null, nama varchar(20) not null, foto varchar(255), cover varchar(255), email varchar(30) not null unique, password varchar(30) not null, primary key (nama), primary key (UserId));



create table status(
statusId int not null, link varchar(255) not null, date datetime not null, place varchar(255) not null, text varchar(255) not null, username varchar(30) not null, primary key(statusId), foreign key (username) references user(nama) on delete cascade);

create table comment(commenId int not null,
 text varchar(255) not null, tanggal date, parent int,  postId int not null,  primary key (commenId), foreign key (parent) references comment(commenId) on delete cascade, foreign key (postId) references status(statusId) );



INSERT INTO user  VALUES
('1', 'Bintang', 'bintang.jpg', 'cover1.jpg', 'bintang@gmail', 'passw123'),
('2', 'Alya', 'alya.png', 'cover2.jpg', 'alya@gmail', 'qweq'),
('3', 'Rizky', 'rizky.jpeg', 'cover3.jpg', 'rizky@gmial', '9009'),
('4', ' Nadia', 'nadia.jpg', 'cover4.jpg', 'nadia@gmial', 'nafid'),
('5', 'Dimas', 'dimas.png', 'cover5.jpg', 'dimas@gmail', 'diman'),
('6', 'Siti', 'siti.jpg', 'cover6.jpg', 'siti@gmial', '243'),
('7', 'rido', 'rido.jpeg', 'coverrido.jpg', 'rido@gmial', '9fwee'),
('8', 'Andi', 'andipo.jpeg', 'andi.jpg', 'andi@gmial', 'gwge'),
('9', 'kuman', 'kumaAn.jpeg', 'kuman.jpg', 'kuman@gmial', '0ioho'),
('10', 'varika', 'fqfwf.jpeg', 'vewf.jpg', 'vvwef@gmial', 'fewf');


INSERT INTO status  VALUES
(1, 'contoh.com', '2025-10-30 09:15:00', 'Jakarta', 'Hari 1 di kantor', 'Bintang'),
(2, 'contoh.com', '2025-10-30 10:05:00', 'Bandung', 'ngeteh enak juga', 'Alya'),
(3, 'contoh.com', '2025-10-29 18:40:00', 'Surabaya', 'ngoding seru', 'Rizky'),
(4, 'contoh.com', '2025-10-29 21:10:00', 'Yogyakarta', 'sunset di jawa', 'Nadia'),
(5, 'contoh.com', '2025-10-28 14:25:00', 'Malang', 'akhirnya selesai', 'Dimas'),
(6, 'contoh.com', '2025-10-28 19:55:00', 'Semarang', 'filem nya seru banget', 'Siti'),
(7, 'contoh.com', '2025-10-27 08:30:00', 'Depok', 'joging di hari apa', 'Bintang'),
(8, 'contoh.com', '2025-10-27 11:10:00', 'Bali', 'enak libuaran kemana', 'kuman'),
(9, 'contoh.com', '2025-10-29 11:23:00', 'Demak', 'sawah hijau', 'varika'),
(10, 'contoh.com', '2025-10-28 12:10:00', 'Batam', 'Ada jembatn barelang', 'rido');

INSERT INTO comment VALUES
(1, 'kanto aku juga', '2025-10-31', NULL, 1),
(2, 'Setuju banget sama ini.', '2025-10-31', NULL, 1),
(3, 'ngeteh apa sis!', '2025-10-31', NULL, 2),
(4, 'neng keni enak', '2025-10-31', NULL, 2),
(5, 'mata mu.', '2025-10-30 12:45:00', NULL, 3),
(6, 'Mantap, lanjutkan!', '2025-10-30', NULL, 3),
(7, 'Postingan ini bikin semangat.', '2025-10-30', NULL, 4),
(8, 'jawa mana ni?', '2025-10-30', NULL, 4),
(9, 'keren dimas', '2025-10-29', NULL, 5),
(10, 'hebat dimas.', '2025-10-29', NULL, 5);

